import React from 'react';
import { Container, Row, Col } from 'react-grid-system';
import hosp1 from "../../assesst/hospital1.jpg";
import hosp2 from "../../assesst/hospital2.jpg";
import './feature1.css';
export default function feature1() {
  return (
    <section id='about' className='feature1'>
    <Container>
        <Row>
            <Col sm={6}>
            <h1>WHO WE ARE</h1>
                <h3>Why choose HeWe</h3>
                <h5>In this speedy world of medicine, it is a itimidating task to manage a multi-talent hospital.This virtual aid is a computer or web based system that makes easy managing
                the work of hospital or any medical set up.This will help in building the entire work as paperless. It combines 
                all the information regarding to pateints,doctors,staffs,hospital administrative details and so on, into one website..</h5>
                <Container>
                    <Row>
                        <Col sm={6}>
                            <h3><i class="zmdi zmdi-check"></i> Doctors</h3>
                            <h5>It includes the list of doctors and their plans. It also includes doctors emergency number. It makes system easy to handle.
                            This system can help doctors to edit their schedule accordingly. It includes a list of the obtainable medicines for the particular diseases so
                            that the doctor can effortlessly look for an alternative when in need.</h5>
                        </Col>
                        <Col sm={6}>
                            <h3><i class="zmdi zmdi-check"></i> Patient</h3>
                            <h5>New patients can be registered in the system. An electronic 
                            medical record system is in-built that stores all the basuc and medical
                            information of the patient.
                            Also there is feature of adding photos of the patient as an identity proof which
                            helps in medico-legal cases of fraud identities. It also helps to manage patient profile.</h5>
                        </Col>
                    </Row>
                    <Row>
                        <Col sm={6}>
                            <h3><i class="zmdi zmdi-check"></i> Staffs</h3>
                            <h5>It includes all the information related to the staff members
                            whether they are nurses,wardboy,sweepers,etc. Also it includes the timings of the nurses amd ward boys
                            on duty with their particular ward numbers.
                            The instruction given to the nurses or wardboys for each patient are entered in the system
                            which helps to manage the pateint health on time.</h5>
                        </Col>
                        <Col sm={6}>
                            <h3><i class="zmdi zmdi-check"></i> Billings</h3>
                            <h5>A distinct automated division is meant for the billing purposes. Vitual Aid software
                            helps to give an abstract of all the expenses of a patient at one time and produce a complete bill at the end of the discharge.</h5>
                        </Col>
                    </Row>
                </Container>
            </Col>
            <Col sm={6}>
                <img src={hosp1} alt="" className='featureImg'/>
                <img src={hosp2} alt="" className='featureImg'/>
            </Col>
        </Row>
    </Container>                
</section>
  )
}
