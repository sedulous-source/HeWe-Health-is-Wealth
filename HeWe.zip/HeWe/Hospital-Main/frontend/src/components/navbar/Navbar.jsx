import React from 'react';
import "./navbar.css"
import { Link } from 'react-router-dom';
const Navbar = () => {
  return (
    <div className="navbar">
        <div className="navContainer">
            <Link to='/' className="logo"><b>HeWe : Health is Wealth</b></Link>
            <div className="navItems">
                <Link to="/register" className="navButton">Register</Link>
                <Link to="/login" className="navButton">Login</Link>
            </div>
        </div>
    </div>
  )
}

export default Navbar;
