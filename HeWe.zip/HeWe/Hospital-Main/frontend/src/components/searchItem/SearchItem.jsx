import "./searchItem.css"
import React from 'react';
import {Link} from "react-router-dom";
import hos1 from '../../assesst/medicity.jpg';
import hos2 from '../../assesst/narayan.jpg';
import hos3 from '../../assesst/phoenix.png';
import hos4 from '../../assesst/srijan.jpg';
import hos5 from '../../assesst/jeevan.jpg';
const SearchItem = () => {
  
  return (
    <>
    <div className="navbar">
        <div className="navContainer">
            <Link to='/' className="logo"><b>HeWe : Health is Wealth</b></Link>
            <div className="navItems">
                <Link to="/" className="navButton">Back</Link>
            </div>
        </div>
    </div>
    <div className="searchItem">
      <img
        src= {hos1}
        alt=""
        className="siImg"
      />

      <div className="siDesc">
        <h1 className="siTitle">UNITED MEDICITY</h1>
        <span className="siDistance">Rawatpur, near Prayagraj, Airport, Prayagraj, Uttar</span>
        <span className="siTaxiOp">30 Mins from Prayagraj Jn.</span>
        <span className="siSubtitle">
          Air Conditoning Wards
        </span>
        <span className="siFeatures">
          Ambulance service is provided at lower rates
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.9</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Minimal Prices</span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <a href = "https://www.unitedmedicity.com/" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Visit Website</button>
          </a>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
       src= {hos2}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">NARAYAN SWAROOP HOSPITAL</h1>
          <span className="siDistance">40, A, Neem Sarai Rd, Mundera Mandi, Dhoomanganj, Prayagraj, Uttar Pradesh 211011.</span>
        <span className="siTaxiOp">16 Mins from Prayagraj Jn.</span>
        <span className="siSubtitle">
          Air Conditoning Wards
        </span>
        <span className="siFeatures">
          Ambulance service is provided at lower rates
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Minimal Prices</span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <a href = "http://www.narayanswaroop.com/" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Visit Website</button>
          </a>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
         src= {hos3}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">PHOENIX HOSPITAL</h1>
        <span className="siDistance"> 49/163A, Jawaharlal Nehru Rd, Tagore Town, Prayagraj, Uttar Pradesh 211002</span>
        <span className="siTaxiOp">11 Mins from Prayagraj Jn.</span>
        <span className="siSubtitle">
          Air Conditoning Wards
        </span>
        <span className="siFeatures">
          Ambulance service is provided at lower rates
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>7.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Minimal Prices</span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <a href = "http://phoenixhospital.org/" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Visit Website</button>
          </a>
        </div>
      </div>
    </div>

    <div className="searchItem">
      <img
       src= {hos4}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">SRIJAN HOSPITAL</h1>
        <span className="siDistance">8/1/6 Elgin Road, Lal Bahadur Shastri Marg, Civil Lines, Prayagraj, Uttar Pradesh 211001</span>
        <span className="siTaxiOp">7 Mins from Prayagraj Jn.</span>
        <span className="siSubtitle">
          Air Conditoning Wards
        </span>
        <span className="siFeatures">
          Ambulance service is provided at lower rates
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.2</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Minimal Prices</span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <a href = "https://srijanhospital.com/" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Visit Website</button>
          </a>
        </div>
      </div>
    </div>

    <div className="searchItem">
      <img
       src= {hos5}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">JEEVAN JYOTI HOSPITAL</h1>
        <span className="siDistance">162, Lowther Rd, Himmat Ganj, Bai Ka Bagh, Prayagraj, Uttar Pradesh 211003</span>
        <span className="siTaxiOp">9 Mins from Prayagraj Jn.</span>
        <span className="siSubtitle">
          Air Conditoning Wards
        </span>
        <span className="siFeatures">
          Ambulance service is provided at lower rates
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.6</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Minimal Prices</span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <a href = "https://jeevanjyotihospital.com/" target='_blank' rel="noopener noreferrer">
       <button  className="siCheckButton">Visit Website</button>
       </a>
        </div>
      </div>
    </div>
    </>
  );
};

export default SearchItem;
