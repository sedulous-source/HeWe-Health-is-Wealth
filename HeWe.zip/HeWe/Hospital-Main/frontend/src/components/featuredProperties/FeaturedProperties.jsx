import "./featuredProperties.css";
import React from 'react';
import hos7 from '../../assesst/hos2.jpg';
import hos8 from '../../assesst/hos3.jpg';
import hos9 from '../../assesst/hos4.jpg';
import hos10 from '../../assesst/hos5.jpg';
const FeaturedProperties = () => {
  return (
    <div className="fp">
      <div className="fpItem">
        <img
          src={hos8} alt="" className="fpImg"/>
        <span className="fpName">Single Rooms</span>
      </div>
      <div className="fpItem">
        <img src={hos7} alt="" className="fpImg"/>
        <span className="fpName">Multiple beds</span>
      </div>
      <div className="fpItem">
        <img src={hos10} alt="" className="fpImg"/>
        <span className="fpName">Specialized doctors</span>
      </div>
      <div className="fpItem">
        <img src={hos9} alt="" className="fpImg"/>
        <span className="fpName">Supportive staffs</span>
      </div>
    </div>
  );
};
export default FeaturedProperties;
