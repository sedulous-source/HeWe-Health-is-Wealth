import React from 'react'
import "./feature2.css";
import { Container, Row, Col } from 'react-grid-system';

export default function feature2() {
  return (
    <>
      <Container>
          <Row>
              <Col sm={3}>
                  <i class="zmdi zmdi-hospital-alt hell"></i>
                  <h3 className='hell1'>More Experience</h3>
                  <h4 className='hell1'>The million patients we treat each year prepares us to treat the one who matters most-you.</h4>
              </Col>
              <Col sm={3}>
                  <i class="zmdi zmdi-pin-drop hell"></i>
                  <h3 className='hell1'>The right answers</h3>
                  <h4 className='hell1'>Count on our experts to deliver an accurate diagnosis and the right plan for you the first time.</h4>
              </Col>
              <Col sm={3}>
                  <i class="zmdi zmdi-hospital hell"></i>
                  <h3 className='hell1'>You come first</h3>
                  <h4 className='hell1'>Treatmen at this website is a truly human experience. You're cared for as a person first. </h4>
              </Col>
              <Col sm={3}>
                  <i class="zmdi zmdi-flower hell"></i>
                  <h3 className='hell1'>Innovation with impact</h3>
                  <h5 className='hell1'>All of patient care,education and research are driven to make discoveries that can help you heal.</h5>
              </Col>
          </Row>
      </Container>  
    </>
  )
}
