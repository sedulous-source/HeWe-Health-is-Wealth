import "./featured.css";
import React from 'react';
import hos1 from '../../assesst/medicity.jpg';
import hos2 from '../../assesst/narayan.jpg';
import hos3 from '../../assesst/phoenix.png';
import hos4 from '../../assesst/srijan.jpg';
import hos5 from '../../assesst/jeevan.jpg';
const Featured = () => {
  return (
    <div className="container-fluid">
    <div className="featured">
      <div className="featuredItem">
        <img
          src={hos1}
          alt=""
          className="featuredImg"
        />
        <div className="featuredTitles">
          <h1>United Medicity</h1>
          <h2>Prayagraj</h2>
        </div>
      </div>
      
      <div className="featuredItem">
        <img
          src={hos2}
          alt=""
          className="featuredImg"
        />
        <div className="featuredTitles">
          <h1>Narayan Swaroop</h1>
          <h2>Prayagraj</h2>
        </div>
      </div>
      <div className="featuredItem">
        <img
          src={hos3}
          alt=""
          className="featuredImg"
        />
        <div className="featuredTitles">
          <h1>Phoenix</h1>
          <h2>Prayagraj</h2>
        </div>
      </div>
      <div className="featuredItem">
        <img
          src={hos4}
          alt=""
          className="featuredImg"
        />
        <div className="featuredTitles">
          <h1>Srijan</h1>
          <h2>Prayagraj</h2>
        </div>
      </div>
      <div className="featuredItem">
        <img
          src={hos5}
          alt=""
          className="featuredImg"
        />
        <div className="featuredTitles">
          <h1>Jeevan Jyoti</h1>
          <h2>Prayagraj</h2>
        </div>
      </div>
    </div>
    </div>
  );
};

export default Featured;

