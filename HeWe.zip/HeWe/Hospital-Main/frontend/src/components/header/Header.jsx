import React from 'react';
import "./header.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import "react-date-range/dist/styles.css"; // main css file
import "react-date-range/dist/theme/default.css";
import { Link } from "react-router-dom";
import { faHospital, faStethoscope, faCapsules ,faPrescription , faCalendarCheck,faBookMedical} from '@fortawesome/free-solid-svg-icons'

const Header = ({ type }) => {
  return (
    <div className="header">
      <div className={type === "list" ? "headerContainer listMode" : "headerContainer"}>
      <div className="headerList">
        
        <div className="headerListItem active">
          <FontAwesomeIcon icon={faCalendarCheck}/>
          <Link to="/register" className='linking'>Book Appointment</Link>
        </div>

        <div className="headerListItem">
          <FontAwesomeIcon icon={faHospital}/>
          <Link to="/search" className='linking'>Find Hospital</Link>
        </div>

        <div className="headerListItem">
          <FontAwesomeIcon icon={faStethoscope}/>
          <a href='https://sprintmedical.in/chat-with-doctor-online#' target='_blank' class='linking' rel="noopener noreferrer">Consult Online</a>
        </div>

        <div className="headerListItem">
          <FontAwesomeIcon icon={faCapsules}/>
          <a href='https://www.netmeds.com/' target='_blank' class='linking' rel="noopener noreferrer">Buy Medicine</a>
        </div>

        <div className="headerListItem">
          <FontAwesomeIcon icon={faBookMedical}/>
          <a href='#about' className='linking'>Who We Are  About Us</a>
        </div>

        <div className="headerListItem">
          <FontAwesomeIcon icon={faPrescription}/>
          <a href='https://qxmd.com/calculate/calculator_236/findrisc-diabetes-risk-calculator' target='_blank' class='linking' rel="noopener noreferrer">Diabetes Calculator</a>
        </div>
        </div>
        { type !== "list" && (
          <>
          <h1 className="headerTitle">The heart of your healthcare. </h1>
        <p className="headerDesc"><b> HeWe</b> aims at providing the medical consultation and appointments with the smooth and simple procedure.
        </p>
        <Link to="register"><button className="headerBtn">Sign in / Register</button></Link>
        </>) }
      </div>
    </div>
  );
};

export default Header;
