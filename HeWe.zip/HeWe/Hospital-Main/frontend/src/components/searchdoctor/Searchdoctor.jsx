import "./searchdoctor.css"
import React from 'react';
import hos15 from '../../assesst/bansal.jpg';
import hos16 from '../../assesst/sunil.jpg';
import hos17 from '../../assesst/agrawal.jpg';
import hos18 from '../../assesst/jaiswal.jpg';
import hos19 from '../../assesst/umesh.jpg';
import {Link} from "react-router-dom";
const Searchdoctor = () => {
  
  return (
    <>
    <div className="navbar">
        <div className="navContainer">
            <Link to='/' className="logo"><b>HeWe</b></Link>
            <div className="navItems">
                <Link to="/" className="navButton">Logout</Link>
                <Link to="/features" className="navButton">Back</Link>
            </div>
        </div>
    </div>
    <div className="searchItem">
      <img
        src= {hos15}
        alt=""
        className="siImg"
      />

      <div className="siDesc">
        <h1 className="siTitle">Dr.VANDANA BANSAL</h1>
        <span className="siDistance">Jeevan Jyoti Hospital, 162, Lowther Rd, Bai Ka Bagh, Prayagraj, Uttar Pradesh 211003</span>
        <span className="siTaxiOp">MBBS, MS, GYNECOLOGIST</span>
        <span className="siSubtitle">
          36 years of Experience
        </span>
        <span className="siFeatures">
        Dr. Vandana Bansal practices at Jeevan Jyoti Hospital. 
        She completed MBBS from Rajendra Institute of Medical Sciences, 
        Ranchi in 1985. Some of the services provided by the doctor are: Complicated Pregnancy Treatment,Laparoscopic Gynaecology,
        Natural Cycle IVF,Lactation Counselling and Fertility Conserving Procedures etc.
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.9</button>
        </div>
        <div className="siDetailTexts">
          <a href = "https://www.practo.com/allahabad/doctor/vandana-bansal-gynecologist-obstetrician" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Know About Doctor</button>
          </a>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
       src= {hos16}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Dr. SUSHIL KUMAR</h1>
          <span className="siDistance">Dwarka Hospital Allahabad</span>
        <span className="siTaxiOp">MBBS , Radiologist</span>
        <span className="siSubtitle">
          18 Years of Experience
        </span>
        <span className="siFeatures">
        Dr. Sushil Kumar Mishra is a Doctor in George Town, Allahabad and has an experience of 18 years in this field. 
        Dr. Sushil Kumar Mishra practices at Arogya Neuro Clinic in George Town, Allahabad. 
        He completed MBBS from Maharani Laxmi Bai Medical College Jhansi in 1998 and
         MD - Medicine from Maharani Laxmi Bai Medical College Jhansi in 2003.
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <a href = "https://www.practo.com/allahabad/doctor/dr-sushil-kumar-mishra-1-neurologist" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Know About Doctor</button>
          </a>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
         src= {hos17}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Dr. GK AGRAWAL</h1>
        <span className="siDistance"> Agrawal Poly Clinic , Allahabad</span>
        <span className="siTaxiOp">MBBS, PHYSICIAN</span>
        <span className="siSubtitle">
          36 years of Experience
        </span>
        <span className="siFeatures">
        Dr. GK Agrawal is a Doctor in George Town, Allahabad and has an experience of 36 years in this field. 
        Dr. GK Agrawal practices at Agrawal Poly Clinic in George Town, Allahabad. 
        He completed MBBS from Motilal Nehru Medical College in 1986
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>7.5</button>
        </div>
        <div className="siDetailTexts">
          <a href = "https://www.practo.com/allahabad/doctor/gk-agrawal-pulmonologist" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Know About Doctor</button>
          </a>
        </div>
      </div>
    </div>

    <div className="searchItem">
      <img
       src= {hos18}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Dr. SJ JAISWAL</h1>
        <span className="siDistance">Prakash Medical Center , Rajroopur, Allahabad</span>
        <span className="siTaxiOp">MD - General Medicine, MBBS ,Consultant Physician</span>
        <span className="siSubtitle">
          19 Years of Experience
        </span>
        <span className="siFeatures">
        Dr. SJ Jaiswal is a Consultant Physician in Rajrooppur, Allahabad and has an experience of 28 years in this field. 
        Dr. SJ Jaiswal practices at Prakash Medical Centre in Rajrooppur, Allahabad. 
        He completed MD - General Medicine from GSVM Medical College Kanpur in 2000 and MBBS from L.P.S Institute of Cardiology, 
        G.S.V.M Medical College, Kanpur in 1994.
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.2</button>
        </div>
        <div className="siDetailTexts">
          
          <a href ="https://www.practo.com/allahabad/doctor/dr-sj-jaiswal-general-physician" target='_blank' rel="noopener noreferrer">
          <button className="siCheckButton">Know Your Doctor</button>
          </a>
        </div>
      </div>
    </div>

    <div className="searchItem">
      <img
       src= {hos19}
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Dr. UMESH SINGH</h1>
        <span className="siDistance">162, Lowther Rd, Himmat Ganj, Bai Ka Bagh, Prayagraj, Uttar Pradesh 211003</span>
        <span className="siTaxiOp">MBBS, MS - Orthopaedics ,Orthopedist, Joint Replacement Surgeon</span>
        <span className="siSubtitle">
          36 Years of Experience
        </span>
        <span className="siFeatures">
        Dr. Umesh Singh is an experienced surgeon having more than 30 years of experience in Orthopedics. 
        He is the prominent personality in the world of non-invasive and invasive orthopaedic procedures. 
        He has a special interest in knee and hip replacement as well as in trauma surgery.
        </span>
        <span className="siCancelOp">Online Appointment </span>
        <span className="siCancelOpSubtitle">
         You can book your consultation with doctor 24*7
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.6</button>
        </div>
        <div className="siDetailTexts">
          <a href = "practo.com/allahabad/doctor/dr-umesh-singh-1-orthopedist" target='_blank' rel="noopener noreferrer">
       <button  className="siCheckButton">Know Your Doctor</button>
       </a>
        </div>
      </div>
    </div>
    </>
  );
};

export default Searchdoctor;