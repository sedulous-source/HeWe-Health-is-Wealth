import "./propertyList.css";
import React from 'react';
import hos1 from '../../assesst/blood.jpg';
import hos2 from '../../assesst/ct.jpg';
import hos3 from '../../assesst/icujpg.jpg';
import hos4 from '../../assesst/nicu.jpg';
import hos5 from '../../assesst/ot.jpg';
const PropertyList = () => {
  return (
    <div className="pList">
      <div className="pListItem">
        <img
          src={hos1}
          alt=""
          className="pListImg"
        />
        <div className="pListTitles">
          <h1>Blood donation rooms</h1>
        </div>
      </div>
      <div className="pListItem">
        <img
          src={hos2}
          alt=""
          className="pListImg"
        />
        <div className="pListTitles">
          <h1>CT Scan</h1>
        </div>
      </div>
      <div className="pListItem">
        <img
          src={hos3}
          alt=""
          className="pListImg"
        />
        <div className="pListTitles">
          <h1>Operation theatre</h1>
        </div>
      </div>
      <div className="pListItem">
        <img
          src={hos4}
          alt=""
          className="pListImg"
        />
        <div className="pListTitles">
          <h1>N-ICU</h1>
        </div>
      </div>
      <div className="pListItem">
        <img
          src={hos5}
          alt=""
          className="pListImg"
        />
        <div className="pListTitles">
          <h1>ICU</h1>
        </div>
      </div>
    </div>
  );
};

export default PropertyList;
