import React from 'react'
import "./home.css";
import Navbar from "../../components/navbar/Navbar";
import Header from "../../components/header/Header";
import Featured from "../../components/featured/Featured";
import PropertyList from '../../components/propertyList/PropertyList';
import FeaturedProperties from '../../components/featuredProperties/FeaturedProperties'
import MailList from '../../components/mailList/MailList';
import Footer from '../../components/footer/Footer';
import Feature1 from '../../components/feature1/feature1';
import Feature2 from "../../components/feature2/feature2";
const Home = () => {
  return (
    <div>
      <Navbar/>
      <Header/>
      <div className="homeContainer"></div>
      <h1 className="homeTitle">Hospitals</h1>
      <Featured/>
      <h1 className="homeTitle">Services provided</h1>
        <PropertyList/>
      <h1 className="homeTitle">Accommodation facilities</h1>
      <FeaturedProperties/>
      <Feature1/>
      <Feature2/>
      <MailList/>
      <Footer/>
    </div>
  );
};

export default Home;
