import React from 'react';
import {Row,Col} from "react-grid-system"
import './feature.css';
import pic1 from "../../assesst/patient.jpg";
import pic2 from "../../assesst/doc2.png";
import pic3 from "../../assesst/nurse.png";
import {Link} from "react-router-dom";
const Features = () => {
  return (
      <>
    <div className="navbar">
        <div className="navContainer">
            <Link to="/" className="logo"><b>HeWe : Health is Wealth</b></Link>
            <div className="navItems">
                <Link to="/" className="navButton">Logout</Link>
            </div>
        </div>
    </div>
      <div className='features'>
      <h1 className='head'>Are you a....?</h1>
        <Row>
            <Col sm={4}>
                <img src={pic1} alt="patient" className='images'/>
                <Link to="/userlogin" className='name'>PATIENT</Link>
            </Col>
            <Col sm={4}>
                <img src={pic2} alt="patient" className='images'/>
                <Link to="/doctor" className='name'>DOCTOR</Link>
            </Col>
            <Col sm={4}>
                <img src={pic3} alt="patient" className='images'/>
                <Link to="#" className='name'>STAFF</Link>
            </Col>
        </Row>
    </div>
    </>
  )
}

export default Features