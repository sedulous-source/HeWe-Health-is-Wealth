import React, { useState , useEffect} from 'react'
import { Container, Row, Col } from 'react-grid-system';
import './userlogin.css';
import signpic from '../../assesst/fem.jpg';
import {Link,useNavigate} from 'react-router-dom';
export default function userlogin() {
  const navigate=useNavigate();
  const [patient,setPatient]=useState({
    name:"",
    email:"",
    phone:0,
    sex:"",
    address:"",
    city:"",
    height:"",
    weight:""
  })
  const [formErrors,setFormErrors]=useState({});
  const [isSubmit,setSubmit]=useState(false);
  const handleChange=(e)=>{
    const name=e.target.name;
    const value=e.target.value;
    setPatient({...patient,[name]:value});
  }
  const postData=async(e)=>{
    e.preventDefault();
    setFormErrors(validate(patient));
    setSubmit(true);
    const {name,email,phone,sex,address,city,height,weight}=patient;
    // eslint-disable-next-line
    const res = await fetch("http://localhost:4000/app/patient",{
      method:"POST",
      headers:{
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        name,email,phone,sex,address,city,height,weight
      })
    })
}
  useEffect(()=>{
    if(Object.keys(formErrors).length === 0 && isSubmit){
      navigate('/');
    }
  })
  const validate=(values)=>{
    const errors={}
    const regex1=/[a-z0-9]+@[a-z]+\.[a-z]{2,3}/;
    const regex2=/^[987][0-9]{9}$/;
    if(!values.name){
      errors.name="Name is required";
    }
    if(!values.email){
      errors.email="Email is required";
    }else if(!regex1.test(values.email)){
              errors.email="This is not a valid email"
    }
    if(!values.phone){
      errors.phone="Phone number is required";
    }else if(!regex2.test(values.phone)){
              errors.phone="Please provide 10 digit number"
    }
    if(!values.sex){
      errors.sex="Sex is required";
    }
    if(!values.address){
      errors.address="Address is required";
    }
    if(!values.city){
      errors.city="City is required";
    }
    if(!values.height){
      errors.height="Height is required";
    }
    if(!values.weight){
      errors.weight="Weight is required";
    }
    return errors;
  }
  return (
    <>
    <div className="navbar">
        <div className="navContainer">
            <Link to='/' className="logo"><b>HeWe : Health is Wealth</b></Link>
            <div className="navItems">
                <Link to="/features" className="navButton">Back</Link>
                <Link to="/" className="navButton">Logout</Link>
            </div>
        </div>
    </div>
    <div className='container'>
    <Container>
      <Row>
        <Col sm={6}>
        <h2>Patient Registration Form</h2>
          <form>
            <div className='form-group'>
              <label htmlFor='name'><i class="zmdi zmdi-account"></i></label>
              <input type="text" name='name' value={patient.name} className='form-control' id='name' autoComplete='off' placeholder='Enter Patient Name' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.name}</p>
            <div className='form-group'>
              <label htmlFor='email'><i class="zmdi zmdi-account-box-mail"></i></label>
              <input type="email" name='email' value={patient.email} className='form-control' id='email' autoComplete='off' placeholder='Your Email' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.email}</p>
            <div className='form-group'>
              <label htmlFor='phone'><i class="zmdi zmdi-phone-in-talk"></i></label>
              <input type="number" name='phone' value={patient.phone} className='form-control' id='phone' autoComplete='off' placeholder='Your Phone Number' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.phone}</p>
            <div className='form-group'>
              <label htmlFor='sex'><i class="zmdi zmdi-male-female"></i></label>
              <input type="text" name='sex' value={patient.sex} className='form-control' id='sex' autoComplete='off' placeholder='Your Sex' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.sex}</p>
            <div className='form-group'>
              <label htmlFor='address '><i class="zmdi zmdi-pin"></i></label>
              <input type="text" name='address' value={patient.address} className='form-control' id='address' autoComplete='off' placeholder='Address Line 1' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.address}</p>
            <div className='form-group'>
              <label htmlFor='city'><i class="zmdi zmdi-pin"></i></label>
              <input type="text" name='city' value={patient.city} className='form-control' id='city' autoComplete='off' placeholder='Your city , state' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.city}</p>
            <div className='form-group'>
              <label htmlFor='height'><i class="zmdi zmdi-star"></i></label>
              <input type="text" name='height' value={patient.height} className='form-control' id='height' autoComplete='off' placeholder='Height (in cms)' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.height}</p>
            <div className='form-group'>
              <label htmlFor='weight'><i class="zmdi zmdi-star"></i></label>
              <input type="text" name='weight' value={patient.weight} className='form-control' id='weight' autoComplete='off' placeholder='Weight (in kgs)' onChange={handleChange}/>
            </div>
            <p className='para'>{formErrors.weight}</p>
            <div className='form-group'>
              <input type="submit" name='signup' id='signup' className='form-submit' onClick={postData}/>
            </div>
            <Link to="/register" className="link">If you don't have account please create one!!</Link>
          </form>
        </Col>
        <Col sm={6}>
          <img src={signpic} alt="" className='signpic'/>
        </Col>
      </Row>
    </Container>
    </div>
    </>
  )
}