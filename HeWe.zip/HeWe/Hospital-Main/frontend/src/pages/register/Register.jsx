import React, { useState , useEffect} from 'react'
import { Container, Row, Col } from 'react-grid-system';
import {Link,useNavigate} from 'react-router-dom';
import './register.css';
import signpic from '../../assesst/signup.png';
const Register = () => {
  const navigate=useNavigate();
  const[user,setuserRegistration]=useState({
    name:"",
    email:"",
    phone:0,
    work:"",
    password:"",
    cpassword:""
  })
  const [formErrors,setFormErrors]=useState({});
  const [isSubmit,setSubmit]=useState(false);

  const handleInput=(e)=>{
    const name=e.target.name;
    const value=e.target.value;
    setuserRegistration({...user,[name]:value});
  }
  const postData=async(e)=>{
    e.preventDefault();
    setFormErrors(validate(user));
    setSubmit(true);
    const {name,email,phone,work,password,cpassword}=user;
    // eslint-disable-next-line
    const res = await fetch("http://localhost:4000/app/register",{
      method:"POST",
      headers:{
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        name,email,phone,work,password,cpassword
      })
    })    
}
  useEffect(()=>{
    if(Object.keys(formErrors).length === 0 && isSubmit){
      // console.log(user);
      navigate('/login');
    }
  })
  const validate=(values)=>{
    const errors={}
    const regex1=/[a-z0-9]+@[a-z]+\.[a-z]{2,3}/;
    const regex2=/^[987][0-9]{9}$/;
    if(!values.name){
      errors.name="Name is required";
    }
    if(!values.email){
      errors.email="Email is required";
    }else if(!regex1.test(values.email)){
              errors.email="This is not a valid email"
    }
    if(!values.phone){
      errors.phone="Phone number is required";
    }else if(!regex2.test(values.phone)){
              errors.phone="Please provide 10 digit number"
    }
    if(!values.work){
      errors.work="Profession is required";
    }
    if(!values.password){
      errors.password="Password is required";
    }else if(values.password < 4){
      errors.password="Password cannot be less than 4 characters";
    }else if(values.password > 8){
      errors.password="Password cannot be greater than 8 characters";
    }
    if(!values.cpassword){
      errors.cpassword="Confirm password is required";
    }else if(values.cpassword!==values.password){
      errors.cpassword="Password doesn't match"
    }
    return errors;
  }

  return (
    <>
    <div className="navbar">
        <div className="navContainer">
            <Link to="/" className="logo"><b>HeWe : Health is Wealth</b></Link>
            <div className="navItems">
                <Link to="/" className="navButton">Back</Link>
                <Link to='/login' className='navButton'>Login</Link>
            </div>
        </div>
    </div>
    <div className='container'>
    <Container>
      <Row>
        <Col sm={6}>
        <h2>SIGN UP</h2>
          <form method='POST' action='/login'>
            <div className='form-group'>
              <label htmlFor='name'><i className="zmdi zmdi-account"></i></label>
              <input type="text" name='name' value={user.name} className='form-control' id='name' autoComplete='off' placeholder='Your Name'  onChange={handleInput} />
            </div>
            <p className='para'>{formErrors.name}</p>
            <div className='form-group'>
              <label htmlFor='email'><i className="zmdi zmdi-email"></i></label>
              <input type="email" name='email' value={user.email} className='form-control' id='email' autoComplete='off' placeholder='Your Email' onChange={handleInput}/>
            </div>
            <p className='para'>{formErrors.email}</p>
            <div className='form-group'>
              <label htmlFor='phone'><i className="zmdi zmdi-phone-in-talk"></i></label>
              <input type="number" name='phone' value={user.phone} className='form-control' maxLength="10" id='phone' autoComplete='off' placeholder='Your Phone Number' onChange={handleInput}/>
            </div>
            <p className='para'>{formErrors.phone}</p>
            <div className='form-group'>
              <label htmlFor='work'><i className="zmdi zmdi-slideshow"></i></label>
              <input type="text" name='work' value={user.work} className='form-control' id='work' autoComplete='off' placeholder='Your Profession' onChange={handleInput}/>
            </div>
            <p className='para'>{formErrors.work}</p>
            <div className='form-group'>
              <label htmlFor='password'><i className="zmdi zmdi-lock"></i></label>
              <input type="password" name='password' value={user.password} className='form-control' id='password' autoComplete='off' placeholder='Your Password' onChange={handleInput}/>
            </div>
            <p className='para'>{formErrors.password}</p>
            <div className='form-group'>
              <label htmlFor='cpassword'><i className="zmdi zmdi-lock"></i></label>
              <input type="password" name='cpassword' value={user.cpassword} className='form-control' id='cpassword' autoComplete='off' placeholder='Confirm Your Password' onChange={handleInput}/>
            </div>
            <p className='para'>{formErrors.cpassword}</p>
            <div className='form-group'>
              <input type="submit" name='signup' id='signup' className='form-submit' onClick={postData}/>
            </div>
            <Link to="/login" className="link">Already have a account?</Link>
          </form>
        </Col>
        <Col sm={6}>
          <img src={signpic} alt="" className='signpic'/>
        </Col>
      </Row>
    </Container>
    </div>
    </>
  )
}

export default Register