import React,{useState} from 'react'
import { Container, Row, Col } from 'react-grid-system';
import './Login.css';
import signpic from '../../assesst/login.jpg';
import {Link,useNavigate} from 'react-router-dom';
import axios from "axios";
export default function register() {
  const navigate=useNavigate();
  const [user,setUser]=useState({
    email:"",
    password:""
  })
  const handleChange=e=>{
    const {name,value}=e.target
    setUser({
      ...user,
      [name]:value
    })
  }
  const login=(e)=>{
      e.preventDefault();
      axios.post("http://localhost:4000/app/login",user)
      .then(res=>{
        const result=res.data.message;
        if(result==="user not registered"){
          alert(result);
          navigate('/register');
        }
        else if(result === "password didn't match"){
          alert(result);
        }
        else if(result==="login successful"){
          navigate('/features');
        }
      }
        )

  }
  return (
    <>
    <div className="navbar">
        <div className="navContainer">
            <Link to='/' className="logo"><b>HeWe: Health is Wealth</b></Link>
            <div className="navItems">
                <Link to="/" className="navButton">Back</Link>
                <Link to="/register" className='navButton'>Sign up</Link>
            </div>
        </div>
    </div>
    <div className='container'>
    <Container>
      <Row>
        <Col sm={6}>
        <h2>LOGIN</h2>
          <form>
            <div className='form-group'>
              <label htmlFor='email'><i className="zmdi zmdi-email"></i></label>
              <input type="email" name='email' value={user.email} className='form-control' id='email' autoComplete='off' placeholder='Your Email' onChange={handleChange}/>
            </div>
            <div className='form-group'>
              <label htmlFor='password'><i className="zmdi zmdi-lock"></i></label>
              <input type="password" name='password' value={user.password} className='form-control' id='password' autoComplete='off' placeholder='Your Password' onChange={handleChange}/>
            </div>
            <div className='form-group'>
              <input type="submit" name='signup' id='signup' className='form-submit' onClick={login}/>
            </div>
            <Link to='/register' className='link'>Create an account</Link>
          </form>
        </Col>
        <Col sm={6}>
          <img src={signpic} alt="" className='signpic'/>
            
        </Col>
      </Row>
    </Container>
    </div>
    </>
  )
}
